/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginapp;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        // Use LoginApp static methods for registration
        String regMessage = LoginApp.registerUser();
        System.out.println("Registration: " + regMessage);

        // Only try login if registration succeeded
        if (regMessage.equals("User registered successfully!")) {
            // Get login info 
            String username = JOptionPane.showInputDialog("Enter username to login:");
            String password = JOptionPane.showInputDialog("Enter password to login:");

            boolean success = LoginApp.loginUser(username, password);
            String loginMessage = LoginApp.returnLoginStatus(success);

            System.out.println("Login attempt: " + loginMessage);
        }

        System.out.println("\nRunning manual tests from LoginTest...");
        LoginTest.main(null);
    }
}


