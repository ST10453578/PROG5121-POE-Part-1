/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.loginapp;

public class LoginTest {
    public static void main(String[] args) {
        LoginTest test = new LoginTest();
        test.runAllTests();
    }

    void runAllTests() {
        testValidUsername();
        testInvalidUsername();
        testValidPassword();
        testInvalidPassword();
        testValidCell();
        testInvalidCell();
        System.out.println("\n✅ All tests finished!");
    }

    void testValidUsername() {
        assert LoginApp.checkUserName("kyl_1") : "Valid username test failed";
        System.out.println("✔ testValidUsername passed");
    }

    void testInvalidUsername() {
        assert !LoginApp.checkUserName("kyle11111") : "Invalid username test failed";
        System.out.println("✔ testInvalidUsername passed");
    }

    void testValidPassword() {
        assert LoginApp.checkPasswordComplexity("Ch@&se@Ke99!") : "Valid password test failed";
        System.out.println("✔ testValidPassword passed");
    }

    void testInvalidPassword() {
        assert !LoginApp.checkPasswordComplexity("password") : "Invalid password test failed";
        System.out.println("✔ testInvalidPassword passed");
    }

    void testValidCell() {
        assert LoginApp.checkCellPhoneNumber("+27838968976") : "Valid cell test failed";
        System.out.println("✔ testValidCell passed");
    }

    void testInvalidCell() {
        assert !LoginApp.checkCellPhoneNumber("08966553") : "Invalid cell test failed";
        System.out.println("✔ testInvalidCell passed");
    }
}
