/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginapp;

import javax.swing.JOptionPane;

public class LoginApp {
    
    private static String Username;
    private static String Password;
    private static String CellNumber;
    private static String firstName;
    private static String lastName;

    // Check username: contains underscore & <= 10 chars
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 10;
    }

//     Check password
    public static boolean checkPasswordComplexity(String password) {
        return password.length() >= 8
         && password.matches(".*[A-Z].*")        // at least one uppercase
         && password.matches(".*[0-9].*")        // at least one digit
         && password.matches(".*[!@#$%^&(),.?\":{}|<>].*"); // at least one special
    }

    // Check cellphone: must start with + and be <= 10 digits after code
    public static boolean checkCellPhoneNumber(String phone) {
        return phone.matches("\\+\\d{1,3}\\d{7,10}");
    }

    // Register user
    public static String registerUser() {
        Username = JOptionPane.showInputDialog("Enter username (must contain '_' and max 10 chars):");
        if (!checkUserName(Username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        Password = JOptionPane.showInputDialog("Enter password (min 8 chars, 1 capital, 1 number, 1 special char):");
        if (!checkPasswordComplexity(Password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        CellNumber = JOptionPane.showInputDialog("Enter cellphone (+countrycodeXXXXXXXX):");
        if (!checkCellPhoneNumber(CellNumber)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        firstName = JOptionPane.showInputDialog("Enter your first name:");
        lastName = JOptionPane.showInputDialog("Enter your last name:");

        return "User registered successfully!";
    }

    // Login
    public static boolean loginUser(String username, String password) {
        return username.equals(Username) && password.equals(Password);
    }

    public static String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Main
    public static void main(String[] args) {
        String regMessage = registerUser();
        JOptionPane.showMessageDialog(null, regMessage);

        if (regMessage.equals("User registered successfully!")) {
            String username = JOptionPane.showInputDialog("Enter username to login:");
            String password = JOptionPane.showInputDialog("Enter password to login:");

            boolean success = loginUser(username, password);
            String loginMessage = returnLoginStatus(success);

            JOptionPane.showMessageDialog(null, loginMessage);
        }
    }
}
